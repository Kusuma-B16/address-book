#include <stdio.h>
#include<unistd.h>
#include "file.h"

// ANSI color codes
#define RED "\x1b[31m"
#define GREEN "\x1b[32m"
#define YELLOW "\x1b[33m" 
#define CYAN "\x1b[36m"
#define RESET "\x1b[0m"
// Function to save contacts to a file
void saveContactsToFile(AddressBook *addressBook) 
{
    FILE *fptr=fopen("contacts.csv","w");// Open file in write mode
    if(fptr==NULL)
    {
        return;
    }
    fprintf(fptr,"#%d\n",(addressBook->contactCount)); // Save the total count of contacts
    for(int i=0;i<addressBook->contactCount;i++)
    {  
        // Write contact details in CSV format
        fprintf(fptr,"%s,",addressBook->contacts[i].name);
        fprintf(fptr,"%s,",addressBook->contacts[i].phone);
        fprintf(fptr,"%s\n",addressBook->contacts[i].email);
    }
    fclose(fptr); // Close the file after writing all contacts
}
 // Function to load contacts from a file
void loadContactsFromFile(AddressBook *addressBook) 
{
    FILE *fptr=fopen("contacts.csv","r");   // Open the file in read mode
    if(fptr==NULL)  // Check if the file exists
    {
        printf("%sError: Could not open contacts.csv\n%s", RED, RESET);
       return;// Exit the function if the file does not exist
    }
    int totalContacts;
    if (fscanf(fptr, "#%d\n", &totalContacts) != 1) {
        printf("%sError: Invalid contacts.csv format.\n%s", RED, RESET);
        fclose(fptr);
        return;
    }

    addressBook->contactCount = totalContacts;

    printf("%sLoading contacts [", CYAN);
    fflush(stdout);

    int totalSteps = 100; // Changed to 100 steps
    int delay = 50; // Milliseconds delay (adjust as needed)
    int contactsPerStep = totalContacts / totalSteps;
    int remainingContacts = totalContacts % totalSteps;
    int loadedContacts = 0;

    for (int i = 1; i <= totalSteps; i++) { // Changed i to start at 1
        for (int j = 0; j < contactsPerStep; j++) {
            if (fscanf(fptr, "%[^,],%[^,],%[^\n]\n", addressBook->contacts[loadedContacts].name,
                       addressBook->contacts[loadedContacts].phone,
                       addressBook->contacts[loadedContacts].email) != 3) {
                printf("\n%sError: Invalid contact data in contacts.csv.\n%s", RED, RESET);
                fclose(fptr);
                return;
            }
            loadedContacts++;
        }

        printf("\r%sLoading contacts [" ,CYAN);
        for (int j = 1; j <= totalSteps; j++) { // Changed j to start at 1
            if (j <= i) {
                printf("-");
            } else {
                printf(" ");
            }
        }
        printf("] %d%%", i);
        fflush(stdout);

        #ifdef _WIN32
        Sleep(delay);
        #else
        usleep(delay * 1000);
        #endif
    }

    // Handle remaining contacts
    for (int k = 0; k < remainingContacts; k++) {
        if (fscanf(fptr, "%[^,],%[^,],%[^\n]\n", addressBook->contacts[loadedContacts].name,
                   addressBook->contacts[loadedContacts].phone,
                   addressBook->contacts[loadedContacts].email) != 3) {
            printf("\n%sError: Invalid contact data in contacts.csv.\n%s", RED, RESET);
            fclose(fptr);
            return;
        }
        loadedContacts++;
    }
    printf("\r%sLoading contacts [", CYAN);
    for (int k = 0; k < totalSteps; k++) {
        printf("-");
    }
    printf("] 100%%\n");

    printf("%sContacts loaded successfully.\n%s", GREEN,RESET);

    fclose(fptr);// Close the file after reading
    
}
