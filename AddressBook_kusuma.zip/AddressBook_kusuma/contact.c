#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"
#include <ctype.h>

// ANSI color codes
#define RED "\x1b[31m"
#define GREEN "\x1b[32m"
#define YELLOW "\x1b[33m"
#define BLUE "\x1b[34m"
#define MAGENTA "\x1b[35m"
#define CYAN "\x1b[36m"
#define RESET "\x1b[0m"

int indexpart=-1; // Global variable to store an index

int isvalidname(char* name)
{
    
    int length=strlen(name);// Get the length of the name string
    for(int i=0;i<length;i++)// Loop through each character in the name
    {
        // Check if the character is not an uppercase letter, lowercase letter, or space
        if(!((name[i] >= 'A' && name[i] <= 'Z') || (name[i] >= 'a' && name[i] <= 'z') || (name[i] == ' ')))
        {
            return 0;// Return 0 if an invalid character is found
        }
    }
    return 1;// Return 1 if the name is valid
    
}
int isvalidphonenumber(char* phonenumber)
{
    int phonenumberlength=0;
    int i=0;
    while(phonenumber[i] != '\0')// Calculate the length of the phone number
    {
        phonenumberlength++;
        i++;
    }
    if(phonenumberlength != 10)// Check if the phone number is exactly 10 digits
    {
        return 0;
    }
    for(int i=0;i<phonenumberlength;i++)
    {
        if(!isdigit(phonenumber[i]))// Check if each character is a digit
        {
            return 0;// Return 0 if an invalid character is found
        }
    }
    return 1;// Return 1 if the phone number is valid
}

void isemailexists(char *mailid,AddressBook *addressBook)
{
    int flag=0;
    int i;
    // Loop through the contacts to check if the email exists
    for(i=0;i<addressBook->contactCount;i++)
    {
        if(strcmp(addressBook->contacts[i].email,mailid)==0)
        {
            flag=1; // Set flag if email is found
            indexpart = i; // Store the index of the matching contact
            break;
        }
    }
    if (flag == 1) {
        printf("%s %s %s\n",addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
    } else {
        printf("%sContact Not Found%s\n", RED, RESET);
    }
}

void isphonenumberexists(char *phone,AddressBook *addressBook)
{
    int i,flag=0;
    for(i=0;i<addressBook->contactCount;i++)// Loop through the contacts to check if the phone number exists
    {
        if(strcmp(addressBook->contacts[i].phone,phone)==0)
        {
            flag=1; // Set flag if phone number is found
            indexpart = i; // Store the index of the matching contact
            break;
        }
    }
    if (flag == 1) {
        printf("%s %s %s\n", addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
    } else {
        printf("%sContact Not Found%s\n", RED, RESET);
    }
}

int isnamedelete(char *name, AddressBook *addressBook) {
    int count = 0; // Initialize counter for matching names
    // Loop through contacts to count occurrences of the given name
    for (int i = 0; i < addressBook->contactCount; i++) {
        if (strcmp(addressBook->contacts[i].name, name) == 0) {
            count++;  // Increment count if name matches
        }
    }

    return count; // Return the number of matches found
}

int isnameexists(char *name,AddressBook *addressBook)
{
    
    int i,flag=0;
    int count=0;
    // Loop through contacts to check if the name exists
    for(i=0;i<addressBook->contactCount;i++)
    {
        if(strcmp(addressBook->contacts[i].name,name)==0)
        {
            flag=1; // Name found
            indexpart = i;  // Store index of matching contact
            // Print contact details
            if (flag == 1) {
                printf("%s %s %s\n",addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
            }
        }
    }
            if(flag == 0)
             {
                printf("%sContact Not Found%s\n", RED, RESET);
                searchContact(addressBook);
            }
    return 0;// Always returns 0 
   
}

int isvalidemail(char *email) 
{
    int length = 0, at_pos = -1, dot_pos = -1, i = 0;

    // Check first character (cannot be '@', '.' or special characters)
    if (!(isalnum(email[0]))) 
        return 0;

    while (email[i] != '\0') 
    {
        if (email[i] == '@') 
        {
            if (at_pos != -1) return 0; // More than one '@' is invalid
            at_pos = i;// Store position of '@'
        } 
        else if (email[i] == '.') 
        {
            if (i > 0 && email[i - 1] == '.') return 0; // Prevent ".." in email
            dot_pos = i; // Store position of last '.'
        } 
        else if (!(isalnum(email[i]) || email[i] == '-' || email[i] == '_')) 
        {
            return 0; // Invalid character found
        }

        length++;// Increase length counter
        i++;
    }

    // '@' must exist, not be the first or last character
    // '.' must exist after '@', not be the last character
    if (at_pos < 1 || dot_pos < at_pos + 2 || dot_pos >= length - 1) 
    {
        return 0;// Always returns 0 
    }

    return 1; // Valid email
}

int findIndexByPhone(const char *phone, AddressBook *addressBook) 
{
    // Loop through all contacts in the address book
    for (int i = 0; i < addressBook->contactCount; i++)
    {
        // Compare the given phone number with each contact's phone number
        if (strcmp(addressBook->contacts[i].phone, phone) == 0) {
            return i; // Return index of contact
        }
    }
    return -1; // Not found
}

int findIndexBymail(const char *mail, AddressBook *addressBook)
{
    // Loop through all contacts in the address book
    for (int i = 0; i < addressBook->contactCount; i++)
    {
        // Compare the given email with each contact's email
        if (strcmp(addressBook->contacts[i].email, mail) == 0) {
            return i; // Return index of contact
        }
    }
    return -1; // Not found
}

void listContacts(AddressBook *addressBook) 
{
    /* Define the logic for print the contacts */
    /* printf("%s\n", addressBook->contact[addressBook->contactCount].name);*/
    // Check if the address book is empty
    if(addressBook -> contactCount == 0)
    {
        printf("%scontact list empty\n%s", RED, RESET);
        return; // Exit the function if no contacts are available
    }
     // Loop through all contacts and print their details
     printf ("----------------------+----------------------------------------------\n");
     printf("| %-20s| %-14s| %-28s|\n", "Name","Phone","Email");
     printf ("----------------------+----------------------------------------------\n");

    for(int i=0;i<addressBook->contactCount;i++)
    {
         printf("| %-20s|", addressBook->contacts[i].name); // Print name
         printf(" %-14s|", addressBook->contacts[i].phone); // Print phone number
         printf(" %-28s|\n", addressBook->contacts[i].email);// Print email

         if (i < addressBook->contactCount - 1)
         {
            // printf("--------------------------------------------------------------------------------\n");
            printf ("----------------------+----------------------------------------------\n");
         }
    }
    printf ("----------------------+----------------------------------------------\n");
}

void initialize(AddressBook *addressBook)
{
    // Set the initial contact count to zero
    addressBook->contactCount = 0;
    // populateAddressBook(addressBook);
    // Load contacts from file during initialization (After files)
    loadContactsFromFile(addressBook);
}

void saveAndExit(AddressBook *addressBook) {
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
}


void createContact(AddressBook *addressBook)
{
    /* Define the logic to create a Contacts */

    // Read the name from the user
    char name[20];
    // Prompt the user to enter a name
    printf("Enter the name: ");
    // Keep reading the name until a valid one is provided
    while (1)
    {
        scanf(" %[^\n]", name);// Read the full name including spaces
        // Validate the entered name
        if (isvalidname(name))
        {
            // Copy the valid name into the contact list
            strcpy(addressBook->contacts[addressBook->contactCount].name, name);
            break;// Exit the loop once a valid name is entered
        }
        else
        {
             // If the name is invalid, display an error message and prompt again
            printf("Invalid name! Only letters are allowed. Please enter again: ");
        }
    }

    // Read the contact number
    // Declare a variable to store the phone number
    char number[20];
     // Prompt the user to enter a phone number
    printf("Enter your phone number: ");
    // Keep reading the phone number until a valid one is provided
    while (1)
    {
        getchar(); // Clear any leftover newline character from the input buffer
        scanf("%19[^\n]", number); // Read up to 19 characters to prevent buffer overflow

         // Validate the phone number format
        if(isvalidphonenumber(number)) 
        {
            // Check if the phone number already exists in the address book
            if (findIndexByPhone(number, addressBook) != -1) 
            {
                // If the number already exists, prompt the user to enter a unique number
                printf("Phone number already exists! Please enter a unique number: ");
                continue;// Restart the loop for a new input
            }
            // If the phone number is valid and unique, store it in the contact list
            strcpy(addressBook->contacts[addressBook->contactCount].phone, number);
            break;// Exit the loop after successful input
        }
        else
        {
            // If the number is invalid, display an error message and prompt again
            printf("Invalid number! Only digits allowed (10 digits). Please enter again: ");
        }
    }

    // Read the email ID
    char mail[30];// Declare a variable to store the email
    printf("Enter your Email ID: ");// Prompt the user to enter an email ID
    while (1)// Keep reading the email until a valid one is provided
    {
        scanf(" %[^\n]", mail);// Read the email input
        // Validate the email format
        if (isvalidemail(mail))
        {
            // Check if the email already exists in the address book
            
            if (findIndexBymail(mail, addressBook) != -1) 
            {// If the email already exists, prompt the user to enter a unique one
                printf("email already exists! Please enter a unique email: ");
                continue;
            }
             // If the email is valid and unique, store it in the contact list
            strcpy(addressBook->contacts[addressBook->contactCount].email, mail);
            break;// Exit the loop after successful input
        }
        else
        {
            // If the email is invalid, display an error message and prompt again
            printf("Invalid Email! Please enter again: ");
        }
    }

    // Increase contact count after successful entry
    addressBook->contactCount++;
     // Confirm successful addition of the contact
    printf("%sContact added successfully!\n%s", GREEN, RESET);
}
    // - Check whether the character array contains lowercase, digits and special characters or not
    // - Check whether char - @ and .com is present or not


void searchContact(AddressBook *addressBook) 
{
    /* Define the logic for search */
    //int num=1;
    // Run an infinite loop to keep showing the search menu until the user exits
    while(1)
    {
        printf("%sSearch Contact Menu:\n%s", CYAN, RESET);
        // Display the search options menu
        printf("1. Search by name\n2. Search by phonenumber\n3. Search by Email id\n4. Exit\n");
        int search_choice;// Variable to store user's choice
         // Prompt the user to enter their search choice
        printf("Enter your choice: ");
        scanf("%d",&search_choice);
        char arr[100];
        char input[100];// Buffer to store user input for search
         // Process user's choice using a switch statement
        switch(search_choice)
        {
            case 1:
            // Search contact by name
             // Loop until a valid name is entered
             while (1) {
                printf("Enter Name: ");
                scanf(" %[^\n]", input);

                if (isvalidname(input)) {
                    isnameexists(input, addressBook);
                    break; // Exit loop if name is valid
                } else {
                    printf("%sInvalid name! Only letters are allowed. Please try again.\n%s", RED, RESET);
                }
            }
            break;
            case 2:
            // Search contact by phone number
             // Loop until a valid phone number is entered
             while (1) {
                printf("Enter Phone Number: ");
                scanf(" %[^\n]", input);

                if (isvalidphonenumber(input)) {
                    isphonenumberexists(input, addressBook);
                    break; // Exit loop if phone is valid
                } else {
                    printf("%sInvalid phone number! Please enter a valid 10-digit phone number.\n%s", RED, RESET);
                }
            }
            break;
            case 3:
             // Search contact by email
            // Loop until a valid email is entered
            while (1) {
                printf("Enter Email ID: ");
                scanf(" %[^\n]", input);

                if (isvalidemail(input)) {
                    isemailexists(input, addressBook);
                    break; // Exit loop if email is valid
                } else {
                    printf("%sInvalid email format! Please enter a correct email (e.g., example@email.com).\n%s", RED, RESET);
                }
            }
            break;
            case 4:
            // Exit the search menu
            return;
            default:
            printf("%sInvalid choice! Please enter a number between 1 and 4.\n%s", RED, RESET);
            
        }  
    }
}

void editContact(AddressBook *addressBook)
{
    indexpart=-1;// Reset the global index variable before searching
    while(1)// Display the search options menu
    {
        printf("%sSearch Contact Menu:\n%s", CYAN, RESET);
        printf("1. Search by Name\n2. Search by Phone Number\n3. Search by Email ID\n4. Exit\n");
        int search_choice;// Variable to store user's choice
        printf("Enter your choice: "); // Prompt the user to enter their search choice
        scanf("%d", &search_choice);
        char name[30]; // Buffer to store the name input
        char phone[20];// Buffer to store the phone number input
        char emailid[30];
        int matches;// Variable to track the number of matches
         // Process user's choice using a switch statement
        switch(search_choice)
        {
            case 1:
            // Search contact by name
            printf("Enter your name: ");
            scanf(" %[^\n]",name);
            // Check how many contacts match the given name
            matches = isnamedelete(name, addressBook);

            if(matches==1)
            {
                 // If exactly one match is found, retrieve the contact details
                isnameexists(name, addressBook);
            }

            if (matches > 1) // If multiple contacts found
            {
                printf("%sMultiple contacts found with the same name.\n%s", YELLOW, RESET);

                // Display only contacts with the same name
                for (int i = 0; i < addressBook->contactCount; i++) {
                    if (strcmp(addressBook->contacts[i].name, name) == 0) {
                        printf("Phone: %s | Email: %s\n", addressBook->contacts[i].phone, addressBook->contacts[i].email);
                    }
                }
            
                // Keep asking for a valid phone number
                while (1) {
                    char phone[20];
                    printf("Enter the phone number of the contact you want to edit: ");
                    scanf(" %[^\n]", phone);
            
                    // Find the exact contact using phone number
                    indexpart = findIndexByPhone(phone, addressBook);
            
                    // Check if the entered phone number exists among the matched contacts
                    int valid = 0;
                    for (int i = 0; i < addressBook->contactCount; i++) {
                        if (strcmp(addressBook->contacts[i].name, name) == 0 && strcmp(addressBook->contacts[i].phone, phone) == 0) {
                            valid = 1;
                            break;
                        }
                    }
            
                    if (valid) {
                        break; // Exit loop if a valid phone number is entered
                    } else {
                        printf("%sInvalid phone number! Please enter a valid phone number from the list.\n%s", RED, RESET);
                    }
                }
            }
            
               // isnameexists(addressBook->contacts[addressBook->contactCount].name, addressBook);
            break;
            case 2:
            // Search contact by phone number
            while(1)
            {
                printf("Enter the phone number: ");
                scanf(" %[^\n]", phone);
                if(isvalidphonenumber(phone)) 
                {
                      // Check if the phone number already exists in the address book
                     if (findIndexByPhone(phone, addressBook) != -1) 
                    {
                     // If the number already exists, prompt the user to enter a unique number
                     printf("Phone number already exists! Please enter a unique number: ");
                     continue;// Restart the loop for a new input
                    }
                    // If the phone number is valid and unique, store it in the contact list
                strcpy(addressBook->contacts[addressBook->contactCount].phone, phone);
                break;// Exit the loop after successful input
                }
                else
                {
                // If the number is invalid, display an error message and prompt again
                 printf("Invalid number! Only digits allowed (10 digits). Please enter again: ");
                }
            }
                break;
            case 3:
             // Search contact by email
             while(1)
             {
             printf("Enter the Email id: ");
                scanf(" %[^\n]", emailid);
                if (isvalidemail(emailid))
                {
                   // Check if the email already exists in the address book
            
                     if (findIndexBymail(emailid, addressBook) != -1) 
                     {// If the email already exists, prompt the user to enter a unique one
                          printf("email already exists! Please enter a unique email: ");
                          continue;
                     }
                    // If the email is valid and unique, store it in the contact list
                    strcpy(addressBook->contacts[addressBook->contactCount].email, emailid);
                   break;// Exit the loop after successful input
                }
                else
               {
                   // If the email is invalid, display an error message and prompt again
                     printf("Invalid Email! Please enter again: ");
                }
            }
                break;
            case 4:
             // Exit the edit menu
                return;
            default:
             // Handle invalid input
                printf("%sInvalid choice. Try again.\n%s", RED, RESET);
                break;
        }  
        break;// Exit the loop after one search attempt
    }

    if(indexpart != -1)
    {
        printf("%sEdit Menu:\n%s", CYAN, RESET);
        printf("1. Edit Name\n2. Edit Phone Number\n3. Edit Email ID\n4. Exit\n");
        int choice;// Variable to store user's choice
        // Prompt the user for their edit choice
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch(choice)
        {
            case 1:
                for(int limit = 0; limit < 3; limit++) 
                {
                    printf("Enter the new name: ");
                    scanf(" %[^\n]", addressBook->contacts[indexpart].name);
                    // Validate the new name
                    if(isvalidname(addressBook->contacts[indexpart].name)) 
                    {
                        printf("%sName updated successfully!\n%s", GREEN, RESET);
                        break;
                    } 
                    else 
                    // Notify user about invalid input and remaining attempts
                    {
                        printf("%sInvalid name. Only letters allowed. Attempts left: %d\n%s", RED, 2 - limit,RESET);
                    }
                }
                break;

            case 2:
             /* Edit Phone Number */
                for(int limit = 0; limit < 3; limit++) 
                {
                    printf("Enter the new phone number: ");
                    scanf(" %[^\n]", addressBook->contacts[indexpart].phone);
                     // Validate the new phone number
                    if(isvalidphonenumber(addressBook->contacts[indexpart].phone)) 
                    {
                        printf("%sPhone number updated successfully!\n%s", GREEN, RESET);
                        break;
                    } 
                    else 
                    {
                        // Notify user about invalid input and remaining attempts
                        printf("%sContact not found. Only digits allowed. Attempts left: %d\n%s", RED, 2 - limit,RESET);
                    }
                }
                break;

            case 3:
            /* Edit Email ID */
            for(int limit = 0; limit < 3; limit++) 
                {
                    printf("Enter the new email ID: ");
                    scanf(" %[^\n]", addressBook->contacts[indexpart].email);
                    // Validate the new email
                    if(isvalidemail(addressBook->contacts[indexpart].email)) 
                    {
                        printf("%sEmail updated successfully!\n%s",GREEN, RESET);
                        break;
                    } 
                    else 
                    {
                        // Notify user about invalid input and remaining attempts
                        printf("%sContact not found. Only digits allowed. Attempts left: %d\n%s", RED,2 - limit,RESET);
                    }
                }
                break;

            case 4:
            /* Exit without making any changes */
                return;
            default:
            /* Handle invalid menu selection */
                printf("%sInvalid choice.\n%s", RED, RESET);
        }
    }
    /* Reset the index variable to -1 to indicate no valid selection */
    indexpart = -1;
}
      
void deleteContact(AddressBook *addressBook)
{
   
    indexpart = -1;// Reset index before searching
    char phone[20];// Buffer to store the phone number input
    char emailid[30];

    while (1) // Loop to allow searching for a contact
    { 
        // Display menu options for searching contacts
        printf("%sSearch Contact Menu:\n%s", CYAN, RESET); 
        printf("1. Search by Name\n2. Search by Phone Number\n3. Search by Email ID\n4. Exit\n");
        int search_choice; // Variable to store user's search choice
        printf("Enter your choice: ");
        scanf("%d", &search_choice);// Read user input

        switch (search_choice) // Process user selection
        {
            case 1:// Search by name
                {
                    char name[50];// Array to store the entered name
                    printf("Enter the name: ");
                    scanf(" %[^\n]", name);// Read the name input

                    int matches = isnamedelete(name, addressBook);// Count how many contacts match the name

                    if(matches==1)// If exactly one match is found
                    {
                        isnameexists(name, addressBook);// Display contact details
                    }

                    if (matches > 1) // If multiple contacts have the same name
                    {
                        char phone[20];// Array to store the phone number
                        printf("%sMultiple contacts found. Enter the phone number to delete: %s", YELLOW, RESET);
                        scanf(" %[^\n]", phone);// Read the phone number input
                        indexpart = findIndexByPhone(phone, addressBook);// Find exact contact by phone number
                    }
                }
                break;

            case 2:
            // Search by phone number
            printf("Enter the phone number: ");
            scanf(" %[^\n]", phone);
                isphonenumberexists(phone,addressBook);
                break;

            case 3:
             // Search by email ID
             printf("Enter the Email id: ");
                scanf(" %[^\n]", emailid);
                isemailexists(emailid,addressBook);
                break;

            case 4:
            // Exit the function
                return;

            default:
            // Handle invalid input
                printf("%sInvalid choice. Try again.\n%s", RED, RESET);
                break;
        }  
        break;// Exit the loop after searching
    }

    if (indexpart != -1) // If a valid contact index was found
    {
            // Shift contacts left to remove the deleted contact
                for (int i = indexpart; i < addressBook->contactCount - 1; i++) 
                {
                    addressBook->contacts[i] = addressBook->contacts[i + 1];// Move next contact to current position
                }
                addressBook->contactCount--;// Decrease total contact count after deletion
                printf("%sContact deleted successfully!\n%s", GREEN, RESET);// Confirm deletion
                // break;
    }

    indexpart = -1; // Reset the global index after deletion
}

