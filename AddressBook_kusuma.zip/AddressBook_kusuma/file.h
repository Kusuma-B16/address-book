#ifndef FILE_H
#define FILE_H

#include "contact.h"

void saveContactsToFile(AddressBook *addressBook); // Function to save all contacts to a file for persistent storage
void loadContactsFromFile(AddressBook *addressBook); // Function to load contacts from a file when the program starts

#endif// End of the header file guard
