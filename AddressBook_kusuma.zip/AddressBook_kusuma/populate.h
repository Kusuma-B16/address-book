void populateAddressBook(AddressBook* addressBook);

// Function to pre-fill the address book with sample contacts
// This can be used for testing purposes or initializing default contacts.