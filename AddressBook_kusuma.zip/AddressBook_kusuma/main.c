/*Name:B Kusuma
Project Name:AddressBook project
Date of submission:16/03/2025
Description: An address book project is a program that stores and manages contact information (name, phone, email, etc.). Users can add, view, edit, and delete contacts, and search for specific entries.
             1  The project emphasizes data handling, user interaction, and potentially file storage for persistence.*/

#include "contact.h"



int main()
{
	AddressBook addressBook;// Declare an AddressBook structure to store contacts
	initialize(&addressBook);// Initialize the address book (load existing contacts from file)
	int num=1; // Variable to control the loop (1 = continue, 0 = exit)

	while(num) // Infinite loop until user chooses to exit
	{
		// Display the Address Book menu options
		printf("\nAddress Book Menu:\n");
	printf("1. Create contact\n");
	printf("2. Search contact\n");
	printf("3. Edit contact\n");
	printf("4. Delete contact\n");
	printf("5. List all contacts\n");
	printf("6. Exit\n");
        int choice;
		// Variable to store user’s menu choice
        printf("Enter your choice: ");
        
        // Check if input is valid
        if (scanf("%d", &choice) != 1)
        {
            printf("Invalid input! Please enter a number between 1 and 6.\n");
            while (getchar() != '\n'); // Clear input buffer
            continue; // Restart loop
        }
        
		 // Validate menu choice
		 if (choice < 1 || choice > 6)
		 {
			 printf("Invalid choice! Please enter a number between 1 and 6.\n");
			 continue; // Restart the loop to ask for input again
		 }

		// Perform actions based on user's choice
        switch(choice)
        {
			case 1:
			createContact(&addressBook); // Call function to create a new contact
			break;
			case 2:
			searchContact(&addressBook);// Call function to search for a contact
			break;
			case 3:
			editContact(&addressBook); // Call function to edit an existing contact
			break;
			case 4:
			deleteContact(&addressBook);// Call function to delete a contact
	        break;
	        case 5:
	        listContacts(&addressBook);// Call function to list all saved contacts
	        break;
            case 6:
			saveContactsToFile(&addressBook); // Save contacts before exiting
			return 0;// Exit the program
        }
		// Ask user if they want to continue or exit
		 // Ask user if they want to continue or exit
		 printf("Do you want to continue? (1 = Yes, 0 = No): ");
        
		 // Validate input for continuation
		 if (scanf("%d", &num) != 1 || (num != 0 && num != 1))
		 {
			 printf("Invalid input! Exiting program.\n");
			 break; // Exit loop
		 }
		
	
	}
	return 0;// Return 0 to indicate successful execution                  
           
}
