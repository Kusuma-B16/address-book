#ifndef CONTACT_H
#define CONTACT_H
#include<stdio.h>

#define MAX_CONTACTS 100
// Define a structure to store contact details
typedef struct Contact{
    char name[50]; // Stores the contact's name (max 50 characters)
    char phone[20];  // Stores the contact's phone number (max 20 characters)
    char email[50]; // Stores the contact's email address (max 50 characters)
} Contact;

// Define a structure for the address book containing multiple contacts

typedef struct {
    Contact contacts[MAX_CONTACTS]; // Array of contacts with a maximum limit
    int contactCount;// Stores the current number of contacts in the address book
} AddressBook;

// Function declarations for Address Book operations

void createContact(AddressBook *addressBook);// Function to create a new contact
void searchContact(AddressBook *addressBook); // Function to search for a contact
void editContact(AddressBook *addressBook); // Function to edit an existing contact
void deleteContact(AddressBook *addressBook); // Function to delete a contact
void listContacts(AddressBook *addressBook); // Function to list all contacts
void initialize(AddressBook *addressBook);  // Function to initialize the address book
void saveContactsToFile(AddressBook *AddressBook);// Function to save contacts to a file

#endif // End of header file guard 
